# Arquivo: View_and_Interface/view.py

from http.server import BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
# Importação corrigida para 'controller' (com 'll')
import controller as ctl 
from Model import model as md 

# Simula uma instância do Controller que será usada pela View
# Nota: A importação 'controller' foi mantida com 'll' conforme a refatoração anterior.
controler_instance = ctl.Controler(loginTru=False) 

class DespesaController(BaseHTTPRequestHandler):
    """
    Classe que manipula as requisições HTTP e serve a interface da Biblioteca/Relatórios.
    O nome da classe (DespesaController) é mantido por enquanto para não quebrar a dependência no main.py.
    """

    def _set_headers(self, status=200, content_type='text/html'):
        self.send_response(status)
        self.send_header('Content-type', content_type)
        self.end_headers()

    def do_GET(self):
        """Lida com requisições GET para servir a interface principal da Biblioteca/Relatórios."""
        parsed_path = urlparse(self.path)
        path = parsed_path.path

        if path == '/':
            self._set_headers()
            # Esta função serve o HTML da Biblioteca.
            self.wfile.write(self._build_biblioteca_html().encode('utf-8'))
        
        elif path == '/usuarios':
             # Nova rota para mostrar usuários cadastrados (Exemplo de como usar o novo Controller)
            usuarios = controler_instance.Get_Usuarios_Cadastrados()
            self._set_headers()
            self.wfile.write(self._build_usuarios_html(usuarios).encode('utf-8'))

        elif path == '/acervos':
            # Nova rota para mostrar acervos cadastrados
            acervos = controler_instance.Get_Acervos_Cadastrados()
            self._set_headers()
            self.wfile.write(self._build_acervos_html(acervos).encode('utf-8'))

        else:
            self._set_headers(404)
            self.wfile.write("<h1>404 Not Found - Apenas o módulo de Relatórios está ativo.</h1>".encode('utf-8'))

    def do_POST(self):
        """Lida com requisições POST (simulando cadastro de dados de Usuário)."""
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length).decode('utf-8')
        params = parse_qs(post_data)
        
        path = urlparse(self.path).path

        if path == '/cadastrar_usuario':
            try:
                # Extrai os dados do POST (o controller espera nome, matricula, tipo)
                nome = params.get('nome', [''])[0]
                matricula = params.get('matricula', [''])[0]
                tipo = params.get('tipo', [''])[0]
                
                if nome and matricula and tipo:
                    # Usa o método renomeado do Controller: Ctr_Cadastra_Usuario
                    controler_instance.Ctr_Cadastra_Usuario(nome, matricula, tipo)
                    self._redirect('/') # Redireciona para a página principal
                    return
            except Exception as e:
                pass 

        self._set_headers(400)
        self.wfile.write("<h1>Erro ao processar POST</h1>".encode('utf-8'))

    def _redirect(self, path, status=303):
        """Função auxiliar para redirecionar após um POST bem-sucedido."""
        self.send_response(status)
        self.send_header('Location', path)
        self.end_headers()


    def _build_biblioteca_html(self):
        """
        Gera o HTML principal, incluindo a interface de Relatórios e um formulário
        simples para cadastro de Usuário.
        """
        usuarios_cadastrados = controler_instance.Get_Usuarios_Cadastrados()

        html_form = f"""
            <h3>Cadastrar Novo Usuário</h3>
            <form method="POST" action="/cadastrar_usuario">
                Nome: <input type="text" name="nome" required><br><br>
                Matrícula: <input type="text" name="matricula" required><br><br>
                Tipo (Aluno/Prof.): <input type="text" name="tipo" required><br><br>
                <input type="submit" value="Cadastrar Usuário">
            </form>

            <hr>
            <h3>Usuários Cadastrados (Mock)</h3>
            <table>
                <tr><th>Nome</th><th>Matrícula</th><th>Tipo</th></tr>
        """
        for usuario in usuarios_cadastrados:
            html_form += f"<tr><td>{usuario.nome}</td><td>{usuario.matricula}</td><td>{usuario.tipo_usuario}</td></tr>"
        html_form += "</table>"


        # Conteúdo do relatorios.html (Interface e JS MOCK)
        # Inserido diretamente no build_biblioteca_html
        return f"""
        <!DOCTYPE html>
        <html lang="pt-BR">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>SGBU - Módulo de Relatórios (Equipe 4)</title>
            <style>
                /* --- ESTILOS GERAIS --- */
                body {{
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    margin: 0;
                    padding: 0;
                    background-color: #f4f7f6;
                }}
                .container {{
                    max-width: 1000px;
                    margin: 40px auto;
                    background: #ffffff;
                    padding: 30px;
                    border-radius: 10px;
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
                }}
                h1 {{
                    color: #17a2b8;
                    border-bottom: 3px solid #17a2b8;
                    padding-bottom: 10px;
                    margin-bottom: 30px;
                    text-align: center;
                }}
                /* LINKS/NAVEGAÇÃO SIMPLES */
                .menu-navegacao {{
                    text-align: center;
                    margin-bottom: 20px;
                }}
                .menu-navegacao a {{
                    margin: 0 10px;
                    text-decoration: none;
                    color: #17a2b8;
                    font-weight: 600;
                }}
                .menu-navegacao a:hover {{
                    text-decoration: underline;
                }}
                /* --- ESTILOS DO MENU DE BOTÕES --- */
                .menu-botoes {{
                    display: flex;
                    justify-content: center;
                    margin-bottom: 40px;
                    gap: 15px;
                }}
                .menu-btn {{
                    background-color: #17a2b8;
                    color: white;
                    padding: 12px 25px;
                    border: none;
                    border-radius: 5px;
                    cursor: pointer;
                    font-size: 1em;
                    transition: background-color 0.3s ease;
                }}
                .menu-btn:hover {{
                    background-color: #117a8b;
                }}

                /* --- ESTILOS DA ÁREA DE RELATÓRIO --- */
                .relatorio-area {{
                    padding: 20px;
                    border: 1px solid #dee2e6;
                    border-radius: 8px;
                    background-color: #f8f9fa;
                    min-height: 250px;
                }}
                .relatorio-titulo {{
                    font-size: 1.8em;
                    color: #343a40;
                    margin-bottom: 20px;
                    font-weight: 600;
                }}
                table {{
                    width: 100%;
                    border-collapse: separate;
                    border-spacing: 0;
                    overflow: hidden;
                    border-radius: 8px;
                }}
                th, td {{
                    padding: 15px;
                    text-align: left;
                    border-bottom: 1px solid #e9ecef;
                }}
                th {{
                    background-color: #343a40;
                    color: white;
                    font-weight: 700;
                }}
                tr:nth-child(even) {{
                    background-color: #f1f1f1;
                }}
                tr:hover {{
                    background-color: #e2e6ea;
                }}
                .status-lista {{
                    list-style: none;
                    padding: 0;
                    font-size: 1.1em;
                }}
                .status-lista li {{
                    background: #e9f5f5;
                    margin-bottom: 10px;
                    padding: 10px;
                    border-left: 5px solid #17a2b8;
                    border-radius: 4px;
                }}
            </style>
        </head>
        <body>

        <div class="container">
            <h1>📚 Universidade Tabajara "TecLearn TABAJARA" - Módulo de Relatórios</h1>

            <div class="menu-navegacao">
                <a href="/">HOME (Relatórios e Cadastro)</a>
                <a href="/usuarios">Ver Usuários (Mock)</a>
                <a href="/acervos">Ver Acervos (Mock)</a>
            </div>

            <h2>Interface de Relatórios</h2>
            <div class="menu-botoes">
                <button class="menu-btn" onclick="gerarRelatorioLivros()">Livros Mais Emprestados</button>
                <button class="menu-btn" onclick="gerarRelatorioUsuarios()">Usuários Mais Ativos</button>
                <button class="menu-btn" onclick="gerarRelatorioStatus()">Contagem de Status de Acervo</button>
            </div>

            <div id="relatorio-output" class="relatorio-area">
                <p>Selecione um relatório no menu acima para visualizar os dados. Os dados são simulados via JavaScript (Mock) para validar o contrato e a lógica de apresentação.</p>
            </div>
            
            <hr style="margin: 40px 0;">

            <h2>Interface de Cadastro (View Simplificada)</h2>
            {html_form}

        </div>

        <script>
            // --- SIMULAÇÃO DOS DADOS DO REPOSITÓRIO (MOCK) ---
            const MOCK_DATA = {{
                EMPRESTIMOS: [
                    {{ idUsuario: 1, idLivro: 101, dataEmprestimo: '2025-01-01' }}, 
                    {{ idUsuario: 2, idLivro: 101, dataEmprestimo: '2025-01-05' }}, 
                    {{ idUsuario: 1, idLivro: 102, dataEmprestimo: '2025-02-10' }}, 
                    {{ idUsuario: 3, idLivro: 101, dataEmprestimo: '2025-02-15' }}, 
                    {{ idUsuario: 3, idLivro: 103, dataEmprestimo: '2025-03-01' }},
                ],
                USUARIOS: {{
                    1: {{ matricula: 1, nome: "Fabricio Leitor" }},
                    2: {{ matricula: 2, nome: "Pietro Leitor" }},
                    3: {{ matricula: 3, nome: "Thiago Leitor" }},
                }},
                LIVROS: {{
                    101: {{ id: 101, titulo: "A Magia do Código", autor: "Autor A", status: 'emprestado' }}, 
                    102: {{ id: 102, titulo: "Testes Essenciais", autor: "Autor B", status: 'emprestado' }}, 
                    103: {{ id: 103, titulo: "Clean Code", autor: "Autor C", status: 'disponivel' }}, 
                    104: {{ id: 104, titulo: "Design Patterns", autor: "Autor D", status: 'disponivel' }}, 
                }}
            }};

            // --- LÓGICA DO RELATORIOSERVICE EM JAVASCRIPT ---

            function simularGerarRelatorioLivros() {{
                const contagem = MOCK_DATA.EMPRESTIMOS.reduce((acc, emp) => {{
                    acc[emp.idLivro] = (acc[emp.idLivro] || 0) + 1;
                    return acc;
                }}, {{}});

                let relatorio = Object.keys(contagem).map(idLivro => {{
                    const livro = MOCK_DATA.LIVROS[idLivro] || {{ titulo: 'Livro Desconhecido', autor: 'N/A' }};
                    return {{
                        titulo: livro.titulo,
                        autor: livro.autor,
                        totalEmprestimos: contagem[idLivro]
                    }};
                }});

                relatorio.sort((a, b) => b.totalEmprestimos - a.totalEmprestimos);
                return relatorio;
            }}

            function simularGerarRelatorioUsuarios() {{
                const contagem = MOCK_DATA.EMPRESTIMOS.reduce((acc, emp) => {{
                    acc[emp.idUsuario] = (acc[emp.idUsuario] || 0) + 1;
                    return acc;
                }}, {{}});

                let relatorio = Object.keys(contagem).map(idUsuario => {{
                    const usuario = MOCK_DATA.USUARIOS[idUsuario];
                    
                    if (usuario) {{
                        return {{
                            nome: usuario.nome,
                            matricula: usuario.matricula,
                            totalEmprestimos: contagem[idUsuario]
                        }};
                    }} else {{
                         return {{
                            nome: 'Usuário Desconhecido',
                            matricula: idUsuario,
                            totalEmprestimos: contagem[idUsuario]
                        }};
                    }}
                }});

                relatorio.sort((a, b) => b.totalEmprestimos - a.totalEmprestimos);
                return relatorio;
            }}

            function simularContagemStatus() {{
                let disponivel = 0;
                let emprestado = 0;
                
                Object.values(MOCK_DATA.LIVROS).forEach(livro => {{
                    if (livro.status === 'disponivel') {{
                        disponivel++;
                    }} else if (livro.status === 'emprestado') {{
                        emprestado++;
                    }}
                }});
                return {{ disponivel, emprestado }};
            }}

            // --- FUNÇÕES DE EXIBIÇÃO (Controller) ---

            function gerarRelatorioLivros() {{
                const dados = simularGerarRelatorioLivros();
                let html = '<div class="relatorio-titulo">Relatório de Livros Mais Emprestados</div>';
                html += '<table>';
                html += '<tr><th>Título</th><th>Autor</th><th>Total de Empréstimos</th></tr>';
                
                dados.forEach(item => {{
                    html += `<tr><td>${{item.titulo}}</td><td>${{item.autor}}</td><td>${{item.totalEmprestimos}}</td></tr>`;
                }});
                
                html += '</table>';
                document.getElementById('relatorio-output').innerHTML = html;
            }}

            function gerarRelatorioUsuarios() {{
                const dados = simularGerarRelatorioUsuarios();
                let html = '<div class="relatorio-titulo">Relatório de Usuários Mais Ativos</div>';
                html += '<table>';
                html += '<tr><th>Usuário</th><th>Matrícula</th><th>Total de Empréstimos</th></tr>';
                
                dados.forEach(item => {{
                    html += `<tr><td>${{item.nome}}</td><td>${{item.matricula}}</td><td>${{item.totalEmprestimos}}</td></tr>`;
                }});
                
                html += '</table>';
                document.getElementById('relatorio-output').innerHTML = html;
            }}

            function gerarRelatorioStatus() {{
                const dados = simularContagemStatus();
                let html = '<div class="relatorio-titulo">Contagem de Status do Acervo</div>';
                html += '<ul class="status-lista">';
                html += `<li><strong>Total Disponíveis:</strong> ${{dados.disponivel}}</li>`;
                html += `<li><strong>Total Emprestados:</strong> ${{dados.emprestado}}</li>`;
                html += '</ul>';
                document.getElementById('relatorio-output').innerHTML = html;
            }}
        </script>

        </body>
        </html>
        """

    def _build_usuarios_html(self, usuarios):
        """Constrói a visualização de Usuários cadastrados."""
        html = """
        <!DOCTYPE html>
        <html><head><title>Usuários Cadastrados</title>
        <style>body{{font-family:Arial;margin:20px;}} .container{{max-width:800px;margin:auto;}} table{{width:100%;border-collapse:collapse;}} th,td{{border:1px solid #ddd;padding:8px;}} th{{background-color:#f2f2f2;}}</style>
        </head><body>
            <div class="container">
            <h2>Lista de Usuários Cadastrados</h2>
            <p><a href="/">Voltar para Home/Relatórios</a></p>
            <table>
                <tr><th>Nome</th><th>Matrícula</th><th>Tipo</th></tr>
        """
        if not usuarios:
            html += "<tr><td colspan='3'>Nenhum usuário registrado.</td></tr>"
        else:
            for u in usuarios:
                html += f"<tr><td>{u.nome}</td><td>{u.matricula}</td><td>{u.tipo_usuario}</td></tr>"
        
        html += """
            </table>
            </div></body></html>
        """
        return html

    def _build_acervos_html(self, acervos):
        """Constrói a visualização de Acervos (Categorias de Livros)."""
        html = """
        <!DOCTYPE html>
        <html><head><title>Acervos Cadastrados</title>
        <style>body{{font-family:Arial;margin:20px;}} .container{{max-width:800px;margin:auto;}} ul{{list-style:disc;}}</style>
        </head><body>
            <div class="container">
            <h2>Acervos (Seções/Categorias) Cadastrados</h2>
            <p><a href="/">Voltar para Home/Relatórios</a></p>
            <ul>
        """
        for a in acervos:
            html += f"<li>{a.nome}</li>"
        
        html += """
            </ul>
            </div></body></html>
        """
        return html