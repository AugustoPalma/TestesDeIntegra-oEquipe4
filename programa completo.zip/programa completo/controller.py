# Arquivo: controller.py
# Refatorado para o contexto de Biblioteca (SGBU)

from Model import model as md
from Model import User as user 

class Controler():
    def __init__(self, loginTru):
        self.loginTrue = loginTru
    
    # Antigo: Ctr_Adiciona_Despesa -> Ctr_Registra_Emprestimo
    def Ctr_Registra_Emprestimo(self, emprestimo_novo):
        md.adicionar_emprestimo(emprestimo_novo)
        pass 
        
    # Antigo: Get_Despesas -> Get_Emprestimos_Ativos
    def Get_Emprestimos_Ativos(self):
        return md.emprestimos_list

    # Antigo: Get_Total_Mensal -> Get_Total_Emprestimos_Mes
    def Get_Total_Emprestimos_Mes(self, mes):
        return md.calc_livros_emprestados(mes)

    # Mantido, pois a autenticação (User) é uma dependência externa
    def Atutenticar(self, login, senha):
        Usuario_Autenticado = user.User(login, senha)
        return Usuario_Autenticado.autenticar()

    # Antigo: get_Contas_Cadastradas -> Get_Usuarios_Cadastrados
    def Get_Usuarios_Cadastrados(self):
        return md.usuarios_list

    # Antigo: get_Bancos_List -> Get_Nomes_Usuarios
    def Get_Nomes_Usuarios(self):
        list = []  
        for usr in md.usuarios_list:
            list.append (usr.get_nome())
        return list
        
    # Antigo: Ctr_Adiciona_Categoria -> Ctr_Adiciona_Acervo
    def Ctr_Adiciona_Acervo(self, acervo):
        md.adicionar_acervo(acervo)

    # Antigo: Get_Categorias_Cadastradas -> Get_Acervos_Cadastrados
    def Get_Acervos_Cadastrados(self):
        return md.acervos_list

    # Antigo: Ctr_Cadastra_Conta -> Ctr_Cadastra_Usuario
    def Ctr_Cadastra_Usuario(self, nome, matricula, tipo):
        dados_inseridos = [nome, matricula, tipo]
        md.adicionar_usuario(dados_inseridos)


class Ctrl_User(user.User):
    def __init__(self, login, senha):
        super().__init__(login, senha)

    def autenticar(self):
        return super().autenticar()