# Arquivo: Model/model.py
# Refatorado para o contexto de Biblioteca (SGBU)

# --- Classes de Entidades ---

class Emprestimo:
    # Correspondente à Despesa (o evento que gera o dado)
    def __init__(self, id_usuario, id_livro, data_emprestimo, data_devolucao=None):
        self.id_usuario = id_usuario
        self.id_livro = id_livro
        self.data_emprestimo = data_emprestimo
        self.data_devolucao = data_devolucao # Se None, está em aberto

    def get_id_livro(self):
        return self.id_livro

class Acervo:
    # Correspondente à Categoria (tipo de livro ou seção)
    def __init__(self, nome):
        self.nome = nome

class Usuario:
    # Correspondente à Conta (o objeto que realiza a ação)
    def __init__(self, nome, matricula, tipo_usuario):
        self.nome = nome
        self.matricula = matricula
        self.tipo_usuario = tipo_usuario # Ex: Aluno, Professor
    
    def get_nome(self):
        return self.nome

# --- Simulação de Base de Dados (Listas Globais) ---

emprestimos_list = []
usuarios_list = []
acervos_list = []

# Adicionando mocks iniciais
acervos_list.append(Acervo("Programação"))
acervos_list.append(Acervo("Engenharia"))

usuarios_list.append(Usuario("Fabricio Leitor", "12345", "Aluno"))
usuarios_list.append(Usuario("Pietro Dev", "54321", "Professor"))

# --- Funções de Manipulação de Dados (CRUD) ---

def adicionar_emprestimo(emprestimo_novo):
    emprestimos_list.append(emprestimo_novo)

def calc_livros_emprestados(mes):
    # Simula um relatório simples de contagem de empréstimos em um mês
    total = sum(1 for emp in emprestimos_list if emp.data_emprestimo.startswith(mes))
    return total

def adicionar_acervo(nome):
    acervos_list.append(Acervo(nome))

def adicionar_usuario(dados_inseridos):
    nome, matricula, tipo = dados_inseridos
    usuarios_list.append(Usuario(nome, matricula, tipo))